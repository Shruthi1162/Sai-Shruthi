Plant Disease Detection System

This project detects plant leaf diseases using a CNN model
trained on leaf images and deployed using Streamlit.
